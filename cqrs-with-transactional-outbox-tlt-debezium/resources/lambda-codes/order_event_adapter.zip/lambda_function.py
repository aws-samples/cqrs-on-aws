import base64

import json

def lambda_handler(event, context):
    order_events = []
    for order_event in event:
        order_events.append({
            'key': json.loads(base64.b64decode(event[0]['key']).decode()),
            'value': json.loads(base64.b64decode(event[0]['value']).decode())
        })
    return order_events