import base64

import json

def lambda_handler(event, context):
    order_events = []
    for order_event in event:
        order_events.append({
            'key': json.loads(base64.b64decode(order_event['key']).decode()),
            'value': json.loads(base64.b64decode(order_event['value']).decode())
        })
    return order_events