"""Exposes version constant to avoid circular dependencies."""

VERSION = "2.39.1"
