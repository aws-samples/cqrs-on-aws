import json
import boto3

client = boto3.client('ses', region_name='us-east-1')

def lambda_handler(event, context):
    body = json.loads(event['Records'][0]['body'])
    message = json.loads(body['Message'])
    event_value = message['value']

    html = """<html>
    <head></head>
    <body>
      <h1>Thank you for your purchase!</h1>
      <p>Greetings, {name}! Thanks for your purchase! The total value of your purchase was {total_value}.</p>
    </body>
    </html>""".format(
        name=event_value['name'],
        total_value=event_value['order_total'])

    client.send_email(
        Destination={
            'ToAddresses': [event_value['email']]
        },
        Message={
            'Body': {
                'Html': {
                    'Charset': 'UTF-8',
                    'Data': html
                }
            },
            'Subject': {
                'Charset': 'UTF-8',
                'Data': 'Thank you for your purchase!',
            },
        },
        Source='Roberto Perillo <bperillo@amazon.com>'
    )