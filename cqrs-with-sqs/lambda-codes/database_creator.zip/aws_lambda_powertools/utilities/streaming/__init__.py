from aws_lambda_powertools.utilities.streaming.s3_object import S3Object

__all__ = ["S3Object"]
