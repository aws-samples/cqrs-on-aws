def lambda_handler(event, context):
    if event[0]['dynamodb']['Keys']['sk']['S'].startswith('ORDER_EVENT#'):
        return {
            'name': event[0]['dynamodb']['NewImage']['name']['S'],
            'email': event[0]['dynamodb']['NewImage']['email']['S'],
            'total': event[0]['dynamodb']['NewImage']['total']['N'],
            'last_purchase': event[0]['dynamodb']['NewImage']['last_purchase']['N']
        }
    return []