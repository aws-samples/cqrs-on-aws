def lambda_handler(event, context):
    list = []
    for record in event:
        if record['dynamodb']['Keys']['sk']['S'].startswith('ORDER_EVENT#'):
            order_event = {
                'name': record['dynamodb']['NewImage']['name']['S'],
                'email': record['dynamodb']['NewImage']['email']['S'],
                'total': record['dynamodb']['NewImage']['total']['N'],
                'last_purchase': record['dynamodb']['NewImage']['last_purchase']['N']
            }
            list.append(order_event)
    return list