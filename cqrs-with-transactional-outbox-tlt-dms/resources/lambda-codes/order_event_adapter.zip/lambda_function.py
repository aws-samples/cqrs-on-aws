import base64

import json

def lambda_handler(event, context):
    events = []
    for record in event:
        decoded_event = json.loads(base64.b64decode(record['data']).decode())
        if decoded_event['metadata']['operation'] == 'insert':
            events.append(decoded_event['data'])
    return events