from aws_lambda_powertools import Logger

import boto3
import json
import os
import pg8000

session = boto3.session.Session()
client = session.client('secretsmanager',
                        'us-east-1')

secret_value = client.get_secret_value(SecretId=os.environ['SECRET_NAME'])
secret = json.loads(secret_value['SecretString'])

db_host = os.environ['DB_HOST']
db_name = os.environ['DB_NAME']
db_port = os.environ['DB_PORT']

conn = pg8000.connect(database=db_name, user=secret['username'], host=db_host, port=db_port,
                      password=secret['password'])
conn.autocommit = False

logger = Logger()


def lambda_handler(event, context):
    list = []
    for record in event['Records']:
        list.append(int(record['body']))

    cur = conn.cursor()
    delete_statement = "DELETE FROM public.order_event where id in (%s)"

    try:
        cur.execute(delete_statement, (",".join(str(element) for element in list),))
        conn.commit()
        logger.info("Order event table cleared successfully!")
    except Exception as e:
        logger.exception(e)
        conn.rollback()