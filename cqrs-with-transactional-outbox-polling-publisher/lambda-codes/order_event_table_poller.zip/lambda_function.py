from aws_lambda_powertools import Logger

import boto3
import calendar
import json
import os
import pg8000
import uuid

session = boto3.session.Session()
client = session.client('secretsmanager',
                        'us-east-1')

sns = boto3.client('sns')

secret_value = client.get_secret_value(SecretId=os.environ['SECRET_NAME'])
secret = json.loads(secret_value['SecretString'])

db_host = os.environ['DB_HOST']
db_name = os.environ['DB_NAME']
db_port = os.environ['DB_PORT']
sns_arn = os.environ['SNS_ARN']

conn = pg8000.connect(database=db_name, user=secret['username'], host=db_host, port=db_port, password=secret['password'])
conn.autocommit = False

logger = Logger()

def lambda_handler(event, context):
    cur = conn.cursor()

    select_all = "SELECT * FROM public.order_event"

    try:
        cur.execute(select_all)
        results = cur.fetchall()

        for result in results:
            order_event = {
                'messageId': str(uuid.uuid4()),
                "id":  result[0],
                "id_client": result[1],
                "name": result[2],
                "email": result[3],
                "order_total": result[4],
                "event_date": result[5]
            }

            sns.publish(TopicArn=sns_arn, Message=json.dumps(order_event))
        return {
            'statusCode': 200,
            'body': 'Order events sent successfully!'
        }
    except Exception as e:
        logger.exception(e)
        conn.rollback()
        return {
            'statusCode': 500,
            'body': 'An internal error occurred.'
        }